# bc_pdf_vector_importer/svg_geometry_renderer.rb
# Full geometry import via pdftocairo SVG output.
#
# Uses Cairo's rendering engine for all geometry AND text —
# exact same output as the PDF viewer. Handles Form XObjects,
# line weights, dash patterns, fills, and text positioning
# that the pure Ruby parser may miss or approximate.
#
# Falls back to the Ruby parser if pdftocairo is unavailable.
#
# Copyright 2024-2026 BlueCollar Systems — BUILT. NOT BOUGHT.

require 'tmpdir'

module BlueCollarSystems
  module PDFVectorImporter
    module SvgGeometryRenderer

      PDF_PT_TO_INCH = 1.0 / 72.0

      # ---------------------------------------------------------------
      # Main entry. Returns stats hash or nil if pdftocairo unavailable.
      # ---------------------------------------------------------------
      def self.render(model, pdf_path, page_num, media_box, opts = {})
        exe = SvgTextRenderer.find_pdftocairo
        return nil unless exe

        scale = opts[:scale] || 1.0
        import_text = opts[:import_text] != false
        create_faces = opts[:create_faces] != false
        layer_name = opts[:layer_name] || 'PDF Import'
        origin_x = media_box[0].to_f
        origin_y = media_box[1].to_f
        vb_w = (media_box[2] - media_box[0]).abs.to_f
        vb_h = (media_box[3] - media_box[1]).abs.to_f
        vb_w = 2592.0 if vb_w < 1
        vb_h = 1728.0 if vb_h < 1

        # Generate SVG
        svg_path = File.join(Dir.tmpdir,
          "bc_geo_#{Process.pid}_#{Time.now.to_i}_#{rand(100000)}.svg")
        cmd = "\"#{exe}\" -svg -f #{page_num.to_i} -l #{page_num.to_i} " \
              "\"#{pdf_path}\" \"#{svg_path}\""
        ok = system(cmd)
        return nil unless ok && File.exist?(svg_path)

        svg = File.read(svg_path)

        # Parse SVG dimensions
        svg_vb_w = (svg[/width="([^"]+)"/, 1] || vb_w).to_f
        svg_vb_h = (svg[/height="([^"]+)"/, 1] || vb_h).to_f

        # Split into defs and body
        defs_split = svg.split('</defs>')
        defs_section = defs_split[0] || ''
        body_section = defs_split[1] || svg

        # Parse body paths and compute scale factor
        body_paths = parse_body_paths(body_section)
        return nil if body_paths.empty?

        # Compute Cairo internal scale from max path coordinates
        max_x = 0.0; max_y = 0.0
        body_paths.each do |bp|
          bp[:points].each do |pt|
            max_x = pt[0] if pt[0] > max_x
            max_y = pt[1] if pt[1] > max_y
          end
        end

        # Dynamic scale: body coords → viewBox coords
        geo_scale_x = max_x > 0 ? svg_vb_w / max_x : 1.0
        geo_scale_y = max_y > 0 ? svg_vb_h / max_y : 1.0

        stats = { edges: 0, faces: 0, text: 0, glyphs: 0 }

        # Create page group
        page_group = model.active_entities.add_group
        page_group.name = "PDF_Page_#{page_num}"
        entities = page_group.entities

        # Create layers/tags
        base_layer = model.layers[layer_name] || model.layers.add(layer_name)
        dash_layer = model.layers["Dashed"] || model.layers.add("Dashed")
        dashdot_layer = model.layers["Dashdot"] || model.layers.add("Dashdot")

        Sketchup.status_text = "Drawing #{body_paths.length} geometry paths..."

        # Draw geometry paths
        body_paths.each_with_index do |bp, idx|
          if idx % 500 == 0
            Sketchup.status_text = "Drawing geometry: #{idx}/#{body_paths.length} [#{((idx.to_f/body_paths.length)*100).round}%]"
          end

          pts = bp[:points].map do |px, py|
            # Convert: body coords → viewBox coords → SketchUp inches
            pdf_x = (px * geo_scale_x) - origin_x
            pdf_y = (svg_vb_h - py * geo_scale_y) - origin_y
            Geom::Point3d.new(
              pdf_x * PDF_PT_TO_INCH * scale,
              pdf_y * PDF_PT_TO_INCH * scale,
              0.0
            )
          end

          # Remove duplicate consecutive points
          clean = [pts.first]
          pts[1..-1].each { |p| clean << p if p.distance(clean.last) >= 0.001 }
          next if clean.length < 2

          # Choose layer based on line type
          target_layer = base_layer
          if bp[:dash]
            if bp[:dash].include?(' ')
              parts = bp[:dash].split(' ').map(&:to_f)
              target_layer = parts.length > 2 ? dashdot_layer : dash_layer
            end
          end

          begin
            edges = entities.add_edges(clean)
            if edges
              stats[:edges] += edges.length
              edges.each { |e| e.layer = target_layer rescue nil }
            end

            # Create face from closed filled paths
            if create_faces && bp[:filled] && clean.length >= 3 &&
               clean.first.distance(clean.last) < 0.01
              begin
                face = entities.add_face(clean)
                if face
                  stats[:faces] += 1
                  face.layer = base_layer rescue nil
                end
              rescue
              end
            end
          rescue
          end
        end

        # Draw text via SvgTextRenderer (reuse existing glyph component approach)
        if import_text
          Sketchup.status_text = "Rendering text glyphs..."
          glyphs = SvgTextRenderer.send(:parse_glyph_defs, svg)
          placements = SvgTextRenderer.send(:parse_use_placements, svg)

          # Build glyph components
          glyph_defs = {}
          glyphs.each do |glyph_id, path_d|
            next if path_d.strip.empty?
            subpaths = SvgTextRenderer.send(:svg_path_to_points, path_d, scale)
            next if subpaths.empty?
            defn = model.definitions.add("_g_#{glyph_id}")
            subpaths.each do |sp|
              next if sp.length < 2
              begin
                r = defn.entities.add_edges(sp)
                stats[:edges] += r.length if r
              rescue
              end
            end
            glyph_defs[glyph_id] = defn if defn.entities.count > 0
          end

          # Place instances
          text_layer = model.layers["#{layer_name}:Text"] ||
                       model.layers.add("#{layer_name}:Text")
          placements.each_with_index do |p, idx|
            if idx % 500 == 0
              Sketchup.status_text = "Placing text: #{idx}/#{placements.length}"
            end
            defn = glyph_defs[p[:glyph_id]]
            next unless defn
            # Glyph positions are in viewBox coords (no scaling needed)
            pdf_x = p[:x] - origin_x
            pdf_y = (svg_vb_h - p[:y]) - origin_y
            x_inch = pdf_x * PDF_PT_TO_INCH * scale
            y_inch = pdf_y * PDF_PT_TO_INCH * scale
            begin
              inst = entities.add_instance(defn,
                Geom::Transformation.new(Geom::Point3d.new(x_inch, y_inch, 0.0)))
              inst.layer = text_layer rescue nil
              stats[:glyphs] += 1
            rescue
            end
          end
          stats[:text] = stats[:glyphs]
        end

        page_group.layer = base_layer rescue nil

        stats
      rescue => e
        Logger.warn("SvgGeometryRenderer", "Failed: #{e.message}") rescue nil
        nil
      ensure
        begin
          File.delete(svg_path) if svg_path && File.exist?(svg_path)
        rescue
        end
      end

      private

      # ---------------------------------------------------------------
      # Parse <path> elements from SVG body into point arrays.
      # Returns [{ points: [[x,y], ...], filled: bool, dash: str|nil }, ...]
      # ---------------------------------------------------------------
      def self.parse_body_paths(body)
        results = []

        body.scan(/<path\s+([^>]*)\/>/m) do |attrs_str,|
          attrs = attrs_str.to_s

          # Get path data
          d = attrs[/d="([^"]*)"/, 1]
          next unless d && !d.strip.empty?

          # Determine if this is filled or stroked
          is_filled = attrs.include?('fill=') && !attrs.include?('fill="none"')
          is_stroked = attrs.include?('stroke=') && !attrs.include?('stroke="none"')

          # Get dash pattern if any
          dash = attrs[/stroke-dasharray="([^"]*)"/, 1]

          # Parse path into points
          points = path_to_points(d)
          next if points.length < 2

          results << {
            points: points,
            filled: is_filled && !is_stroked,
            stroked: is_stroked,
            dash: dash
          }
        end

        results
      end

      # ---------------------------------------------------------------
      # Parse SVG path d="" into flat array of [x,y] points.
      # Handles M, L, H, V, C, S, Z (absolute only — Cairo uses absolute).
      # ---------------------------------------------------------------
      def self.path_to_points(d)
        tokens = d.scan(/[MLHVCSZmlhvcsz]|[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?/)
        points = []
        cx = 0.0; cy = 0.0
        start_x = 0.0; start_y = 0.0
        cmd = nil; nums = []

        flush = lambda do
          case cmd
          when 'M'
            while nums.length >= 2
              cx, cy = nums.shift(2)
              start_x, start_y = cx, cy
              points << [cx, cy]
            end
          when 'L'
            while nums.length >= 2
              cx, cy = nums.shift(2)
              points << [cx, cy]
            end
          when 'H'
            while nums.length >= 1
              cx = nums.shift
              points << [cx, cy]
            end
          when 'V'
            while nums.length >= 1
              cy = nums.shift
              points << [cx, cy]
            end
          when 'C'
            while nums.length >= 6
              x1, y1, x2, y2, x, y = nums.shift(6)
              # Subdivide cubic bezier
              p0x, p0y = cx, cy
              chord = Math.sqrt((x-p0x)**2 + (y-p0y)**2)
              steps = chord < 5 ? 2 : (chord < 20 ? 3 : 5)
              (1..steps).each do |i|
                t = i.to_f / steps; mt = 1.0 - t
                bx = mt**3*p0x + 3*mt**2*t*x1 + 3*mt*t**2*x2 + t**3*x
                by = mt**3*p0y + 3*mt**2*t*y1 + 3*mt*t**2*y2 + t**3*y
                points << [bx, by]
              end
              cx, cy = x, y
            end
          when 'S'
            while nums.length >= 4
              _, _, x, y = nums.shift(4)
              cx, cy = x, y
              points << [cx, cy]
            end
          when 'Z', 'z'
            if (cx - start_x).abs > 0.1 || (cy - start_y).abs > 0.1
              points << [start_x, start_y]
            end
            cx, cy = start_x, start_y
          end
        end

        tokens.each do |tok|
          if tok =~ /\A[A-Za-z]\z/
            flush.call if cmd
            cmd = tok.upcase
            nums = []
          else
            nums << tok.to_f
          end
        end
        flush.call if cmd

        points
      end

    end
  end
end
